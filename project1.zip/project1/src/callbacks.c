

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "evenement.h"
#include <string.h>

gboolean
fd_on_win_admin_delete_event (GtkWidget *widget,
                              GdkEvent *event,
                              gpointer user_data)
{
    return FALSE;
}

void
on_fd_btn_ajouter1_confirm_clicked (GtkButton *button,
                                    gpointer user_data)
{
    GtkWidget *fd_entry_id;
    GtkWidget *fd_entry_nom;
    GtkWidget *fd_entry_date;
    GtkWidget *fd_entry_heure;
    GtkWidget *fd_entry_lieu;
    GtkWidget *fd_spin_participants;
    GtkWidget *fd_spin_frais;
    GtkWidget *fd_combo_centres;
    GtkWidget *fd_chk_add_option;
    GtkWidget *label_status;
    
    char id[50];
    char nom[100];
    char date[50];
    char heure[50];
    char lieu[100];
    int participants;
    double frais;
    char centre[20];
    int equipements;
    int resultat;

    /* ========== ADD THIS DEBUG SECTION ========== */
    g_print("\n=== DEBUG START ===\n");
    g_print("Looking for widgets from button: %p\n", button);
    
    fd_entry_id = lookup_widget(GTK_WIDGET(button), "fd_entry_id");
    g_print("fd_entry_id: %p\n", fd_entry_id);
    
    fd_entry_nom = lookup_widget(GTK_WIDGET(button), "fd_entry_nom");
    g_print("fd_entry_nom: %p\n", fd_entry_nom);
    
    fd_entry_date = lookup_widget(GTK_WIDGET(button), "fd_entry_date");
    g_print("fd_entry_date: %p\n", fd_entry_date);
    
    fd_entry_heure = lookup_widget(GTK_WIDGET(button), "fd_entry_heure");
    g_print("fd_entry_heure: %p\n", fd_entry_heure);
    
    fd_entry_lieu = lookup_widget(GTK_WIDGET(button), "fd_entry_lieu");
    g_print("fd_entry_lieu: %p\n", fd_entry_lieu);
    
    fd_spin_participants = lookup_widget(GTK_WIDGET(button), "fd_spin_participants");
    g_print("fd_spin_participants: %p\n", fd_spin_participants);
    
    fd_spin_frais = lookup_widget(GTK_WIDGET(button), "fd_spin_frais");
    g_print("fd_spin_frais: %p\n", fd_spin_frais);
    
    fd_combo_centres = lookup_widget(GTK_WIDGET(button), "fd_combo_centres");
    g_print("fd_combo_centres: %p\n", fd_combo_centres);
    
    fd_chk_add_option = lookup_widget(GTK_WIDGET(button), "fd_chk_add_option");
    g_print("fd_chk_add_option: %p\n", fd_chk_add_option);
    
    label_status = lookup_widget(GTK_WIDGET(button), "label_status");
    g_print("label_status: %p\n", label_status);
    
    g_print("=== DEBUG END ===\n\n");
    /* ========== ADD SAFETY CHECKS ========== */
    
    if (!fd_entry_id || !fd_entry_nom || !fd_entry_date || 
        !fd_entry_heure || !fd_entry_lieu || !fd_spin_participants || 
        !fd_spin_frais || !fd_combo_centres || !fd_chk_add_option)
    {
        g_print("ERROR: One or more widgets not found!\n");
        if (label_status)
        {
            gtk_label_set_text(GTK_LABEL(label_status), "ERREUR: Widgets non trouvés!");
        }
        return;
    }
    /* ========== END OF ADDITIONS ========== */
    
    /* Your existing code continues here... */
    strcpy(id, gtk_entry_get_text(GTK_ENTRY(fd_entry_id)));
    
    // ... rest of your code
    fd_entry_id = lookup_widget(GTK_WIDGET(button), "fd_entry_id");
    fd_entry_nom = lookup_widget(GTK_WIDGET(button), "fd_entry_nom");
    fd_entry_date = lookup_widget(GTK_WIDGET(button), "fd_entry_date");
    fd_entry_heure = lookup_widget(GTK_WIDGET(button), "fd_entry_heure");
    fd_entry_lieu = lookup_widget(GTK_WIDGET(button), "fd_entry_lieu");
    fd_spin_participants = lookup_widget(GTK_WIDGET(button), "fd_spin_participants");
    fd_spin_frais = lookup_widget(GTK_WIDGET(button), "fd_spin_frais");
    fd_combo_centres = lookup_widget(GTK_WIDGET(button), "fd_combo_centres");
    fd_chk_add_option = lookup_widget(GTK_WIDGET(button), "fd_chk_add_option");
    label_status = lookup_widget(GTK_WIDGET(button), "label_status");
    
    strcpy(id, gtk_entry_get_text(GTK_ENTRY(fd_entry_id)));
    strcpy(nom, gtk_entry_get_text(GTK_ENTRY(fd_entry_nom)));
    strcpy(date, gtk_entry_get_text(GTK_ENTRY(fd_entry_date)));
    strcpy(heure, gtk_entry_get_text(GTK_ENTRY(fd_entry_heure)));
    strcpy(lieu, gtk_entry_get_text(GTK_ENTRY(fd_entry_lieu)));
    
    participants = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(fd_spin_participants));
    frais = gtk_spin_button_get_value(GTK_SPIN_BUTTON(fd_spin_frais));
    
    const gchar *centre_text = gtk_combo_box_get_active_text(GTK_COMBO_BOX(fd_combo_centres));
    if (centre_text != NULL)
    {
        strcpy(centre, centre_text);
    }
    else
    {
        centre[0] = '\0';
    }
    
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(fd_chk_add_option)))
        equipements = 1;
    else
        equipements = 0;
    
    if (strlen(id) == 0)
    {
        gtk_label_set_text(GTK_LABEL(label_status), "ERREUR:id");
        return;
    }
    
    Evenement e;
    strcpy(e.id, id);
    strcpy(e.nom, nom);
    strcpy(e.date, date);
    strcpy(e.heure, heure);
    strcpy(e.lieu, lieu);
    e.participants_max = participants;
    e.frais = frais;
    strcpy(e.centre, centre);
    e.equipements = equipements;
    
    resultat = ajouter_evenement("evenements.txt", e);



if (resultat == 1) {
    // Refresh the TreeView
    GtkWidget *fd_treeview_evenements = lookup_widget(GTK_WIDGET(button), "fd_treeview_evenements");
    if (fd_treeview_evenements) {
        afficher_evenements(fd_treeview_evenements, "evenements.txt");
    }
    
    // Clear form fields
    gtk_entry_set_text(GTK_ENTRY(fd_entry_id), "");
    gtk_entry_set_text(GTK_ENTRY(fd_entry_nom), "");
    gtk_entry_set_text(GTK_ENTRY(fd_entry_date), "");
    gtk_entry_set_text(GTK_ENTRY(fd_entry_heure), "");
    gtk_entry_set_text(GTK_ENTRY(fd_entry_lieu), "");
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(fd_spin_participants), 0);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(fd_spin_frais), 0.0);
    
    gtk_label_set_text(GTK_LABEL(label_status), "Événement ajouté avec succès!");
}
}

void
fd_on_modifier_search_clicked (GtkButton *button,
                               gpointer user_data)
{
}

void
fd_on_supprimer_confirm_clicked (GtkButton *button,
                                 gpointer user_data)
{
}





/*void
on_fd_btn_rechercher_confirm_clicked (GtkButton *button,
                                 gpointer user_data)
{
}*/
/*
void
on_fd_btn_register_event_clicked (GtkButton *button,
                                 gpointer user_data)
{
}
*/






void
on_fd_btn_rechercher_confirm_clicked (GtkButton *button,
                                  gpointer user_data)
{

GtkWidget *fd_entry_search_nom;
    GtkWidget *fd_treeview_evenements;
    
    char search_nom[100];
    
    /* ========== GET WIDGETS ========== */
    fd_entry_search_nom = lookup_widget(GTK_WIDGET(button), "fd_entry_search_nom");
    fd_treeview_evenements = lookup_widget(GTK_WIDGET(button), "fd_treeview_evenements");
    
    /* ========== VALIDATE WIDGETS ========== */
    if (!fd_entry_search_nom || !fd_treeview_evenements)
    {
        return;
    }
    
    /* ========== GET SEARCH VALUE ========== */
    strcpy(search_nom, gtk_entry_get_text(GTK_ENTRY(fd_entry_search_nom)));
    
    /* ========== CALL FILTERED DISPLAY FUNCTION ========== */
    afficher_evenements_filtre(fd_treeview_evenements, "evenements.txt", search_nom);
}

gboolean
fd_on_win_register_delete_event (GtkWidget *widget,
                                 GdkEvent *event,
                                 gpointer user_data)
{
    return FALSE;
}

void
on_fd_btn_register_event_clicked (GtkButton *button,
                              gpointer user_data)
{
GtkWidget *window = gtk_widget_get_toplevel(GTK_WIDGET(button));
    
    /* Debug: Check if we got the window */
    if (!window || !GTK_IS_WINDOW(window))
    {
        g_warning("Failed to get toplevel window!");
        return;
    }
    
    g_print("Toplevel window found: %p\n", window);
    
    GtkWidget *fd_entry_member_id;
    GtkWidget *fd_entry_register_event_id;
    GtkWidget *label_status_register;
    
    /* ========== GET WIDGETS ========== */
    fd_entry_member_id = lookup_widget(window, "fd_entry_member_id");
    g_print("fd_entry_member_id: %p\n", fd_entry_member_id);
    
    fd_entry_register_event_id = lookup_widget(window, "fd_entry_register_event_id");
    g_print("fd_entry_register_event_id: %p\n", fd_entry_register_event_id);
    
    label_status_register = lookup_widget(window, "label_status_register");
    g_print("label_status_register: %p\n", label_status_register);
    
    /* ========== VALIDATE WIDGETS ========== */
    if (!fd_entry_member_id || !fd_entry_register_event_id || !label_status_register)
    {
        g_warning("One or more widgets not found!");
        return;
    }
    
    char member_id[50];
    char event_id[50];
    int resultat;
    
    /* ========== GET WIDGETS ========== */
    fd_entry_member_id = lookup_widget(window, "fd_entry_member_id");
    fd_entry_register_event_id = lookup_widget(window, "fd_entry_register_event_id");
    label_status_register = lookup_widget(window, "label_status_register");
    
    /* ========== VALIDATE WIDGETS ========== */
    if (!fd_entry_member_id || !fd_entry_register_event_id || !label_status_register)
    {
        g_warning("One or more widgets not found!");
        return;
    }
    
    /* ========== GET VALUES ========== */
    strcpy(member_id, gtk_entry_get_text(GTK_ENTRY(fd_entry_member_id)));
    strcpy(event_id, gtk_entry_get_text(GTK_ENTRY(fd_entry_register_event_id)));
    
    /* ========== VALIDATE REQUIRED FIELDS ========== */
    if (strlen(member_id) == 0)
    {
        gtk_label_set_text(GTK_LABEL(label_status_register), "ERREUR: ID membre requis");
        return;
    }
    
    if (strlen(event_id) == 0)
    {
        gtk_label_set_text(GTK_LABEL(label_status_register), "ERREUR: ID événement requis");
        return;
    }
    
    /* ========== CHECK IF EVENT EXISTS ========== */
    Evenement e = chercher_evenement("evenements.txt", event_id);
    if (strcmp(e.id, "-1") == 0)
    {
        gtk_label_set_text(GTK_LABEL(label_status_register), "ERREUR: Événement non trouvé");
        return;
    }
    
    /* ========== CREATE INSCRIPTION STRUCTURE ========== */
    Inscription i;
    strcpy(i.member_id, member_id);
    strcpy(i.event_id, event_id);
    
    /* ========== CALL EXISTING FUNCTION ========== */
    resultat = affecter_coach_event("inscriptions.txt", i);
    
    /* ========== HANDLE RESULT ========== */
    if (resultat == 1)
    {
        gtk_label_set_text(GTK_LABEL(label_status_register), "Inscription réussie");
        
        /* Clear fields after successful registration */
        gtk_entry_set_text(GTK_ENTRY(fd_entry_member_id), "");
        gtk_entry_set_text(GTK_ENTRY(fd_entry_register_event_id), "");
    }
    else
    {
        gtk_label_set_text(GTK_LABEL(label_status_register), "ERREUR: Échec de l'inscription");
    }
}

/* Function to populate TreeView in registration window */
void
on_fd_win_register_event_show (GtkWidget *widget,
                                gpointer user_data)
{
  
    g_print("\n=== DEBUG: Registration window SHOW called ===\n");
    
    // widget IS the registration window! Don't look it up again.
    
    /* Get TreeView widget directly from this window */
    GtkWidget *treeview = lookup_widget(widget, "fd_treeview_available_events");
    
    if (treeview != NULL) {
        g_print("SUCCESS: Found TreeView at %p\n", treeview);
        g_print("Calling afficher_evenements...\n");
        
        // This calls the function in evenement.c
        afficher_evenements(treeview, "evenements.txt");
        
        g_print("Done!\n");
    } else {
        g_print("ERROR: fd_treeview_available_events not found!\n");
        
        // Try other possible names
        GtkWidget *treeview1 = lookup_widget(widget, "treeview1");
        if (treeview1) {
            g_print("Found 'treeview1', using that instead\n");
            afficher_evenements(treeview1, "evenements.txt");
        }
    }
    
    g_print("=== DEBUG END ===\n\n");

}

// Add this helper function
void list_all_widgets_debug(GtkWidget *widget, int depth) {
    const gchar *name = gtk_widget_get_name(widget);
    const gchar *type = G_OBJECT_TYPE_NAME(widget);
    
    for (int i = 0; i < depth; i++) g_print("  ");
    g_print("%s (%s) at %p\n", name ? name : "(no name)", type, widget);
    
    if (GTK_IS_CONTAINER(widget)) {
        GList *children = gtk_container_get_children(GTK_CONTAINER(widget));
        GList *iter = children;
        while (iter) {
            list_all_widgets_debug(GTK_WIDGET(iter->data), depth + 1);
            iter = iter->next;
        }
        g_list_free(children);
    }
}

/* Optional: Function when a row is selected in TreeView (auto-fill event ID) */
void
on_fd_treeview_available_events_row_activated (GtkTreeView *treeview,
                                               GtkTreePath *path,
                                               GtkTreeViewColumn *column,
                                               gpointer user_data)
{
    GtkTreeIter iter;
    gchar *event_id;
    GtkWidget *fd_entry_register_event_id;
    GtkWidget *window;
    
    /* Get the registration window */
    window = gtk_widget_get_toplevel(GTK_WIDGET(treeview));
    
    /* Get event ID entry widget */
    fd_entry_register_event_id = lookup_widget(window, "fd_entry_register_event_id");
    if (!fd_entry_register_event_id) return;
    
    /* Get selected row data */
    GtkTreeModel *model = gtk_tree_view_get_model(treeview);
    if (gtk_tree_model_get_iter(model, &iter, path))
    {
        /* Assuming column 0 is the event ID */
        gtk_tree_model_get(model, &iter, 0, &event_id, -1);
        
        /* Auto-fill the event ID field */
        gtk_entry_set_text(GTK_ENTRY(fd_entry_register_event_id), event_id);
        
        g_free(event_id);
    }


}

void
on_fd_btn_modifier_confirm_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{

    GtkWidget *fd_entry_mod_id_search;
    GtkWidget *fd_entry_mod_nom;
    GtkWidget *fd_entry_mod_date;
    GtkWidget *fd_entry_mod_heure;
    GtkWidget *fd_entry_mod_lieu;
    GtkWidget *fd_spin_mod_participants;
    GtkWidget *fd_spin_mod_frais;
    GtkWidget *fd_combo_mod_centres;
    GtkWidget *label_statusm;
    
    char id[50];
    char nom[100];
    char date[20];
    char heure[10];
    char lieu[100];
    int participants;
    double frais;
    char centres[50];
    int resultat;
    
    /* ========== GET WIDGETS ========== */
    fd_entry_mod_id_search = lookup_widget(GTK_WIDGET(button), "fd_entry_mod_id_search");
    fd_entry_mod_nom = lookup_widget(GTK_WIDGET(button), "fd_entry_mod_nom");
    fd_entry_mod_date = lookup_widget(GTK_WIDGET(button), "fd_entry_mod_date");
    fd_entry_mod_heure = lookup_widget(GTK_WIDGET(button), "fd_entry_mod_heure");
    fd_entry_mod_lieu = lookup_widget(GTK_WIDGET(button), "fd_entry_mod_lieu");
    fd_spin_mod_participants = lookup_widget(GTK_WIDGET(button), "fd_spin_mod_participants");
    fd_spin_mod_frais = lookup_widget(GTK_WIDGET(button), "fd_spin_mod_frais");
    fd_combo_mod_centres = lookup_widget(GTK_WIDGET(button), "fd_combo_mod_centres");
    label_statusm = lookup_widget(GTK_WIDGET(button), "label_statusm");
    
    /* ========== VALIDATE WIDGETS ========== */
    if (!fd_entry_mod_id_search || !fd_entry_mod_nom || !fd_entry_mod_date || 
        !fd_entry_mod_heure || !fd_entry_mod_lieu || !fd_spin_mod_participants || 
        !fd_spin_mod_frais || !label_statusm)
    {
        g_print("ERROR: Widgets not found for modifier!\n");
        return;
    }
    
    /* ========== GET FORM VALUES ========== */
    strcpy(id, gtk_entry_get_text(GTK_ENTRY(fd_entry_mod_id_search)));
    strcpy(nom, gtk_entry_get_text(GTK_ENTRY(fd_entry_mod_nom)));
    strcpy(date, gtk_entry_get_text(GTK_ENTRY(fd_entry_mod_date)));
    strcpy(heure, gtk_entry_get_text(GTK_ENTRY(fd_entry_mod_heure)));
    strcpy(lieu, gtk_entry_get_text(GTK_ENTRY(fd_entry_mod_lieu)));
    
    participants = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(fd_spin_mod_participants));
    frais = gtk_spin_button_get_value(GTK_SPIN_BUTTON(fd_spin_mod_frais));
    
    /* Get selected centre from combo box */
    if (fd_combo_mod_centres)
    {
        const gchar *centres_text = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(fd_combo_mod_centres));
        if (centres_text != NULL)
        {
            strcpy(centres, centres_text);
        }
        else
        {
            centres[0] = '\0';
        }
    }
    else
    {
        centres[0] = '\0';
    }
    
    /* ========== VALIDATE REQUIRED FIELDS ========== */
    if (strlen(id) == 0)
    {
        gtk_label_set_text(GTK_LABEL(label_statusm), "ERREUR: ID requis pour modification");
        return;
    }
    
    if (strlen(nom) == 0)
    {
        gtk_label_set_text(GTK_LABEL(label_statusm), "ERREUR: Nom requis");
        return;
    }
    
    /* ========== CREATE EVENT STRUCTURE ========== */
    Evenement e;
    strcpy(e.id, id);
    strcpy(e.nom, nom);
    strcpy(e.date, date);
    strcpy(e.heure, heure);
    strcpy(e.lieu, lieu);
    e.participants_max = participants;
    e.frais = frais;
    strcpy(e.centre, centres);
    e.equipements = 0;
    
    /* ========== CALL MODIFICATION FUNCTION ========== */
    resultat = modifier_evenement("evenements.txt",id, e);
    
    /* ========== HANDLE RESULT ========== */
    if (resultat == 0)
    {
        char status_msg[200];
        snprintf(status_msg, sizeof(status_msg), 
                "Événement '%s' modifié avec succès", nom);
        gtk_label_set_text(GTK_LABEL(label_statusm), status_msg);
    }
    else
    {
        gtk_label_set_text(GTK_LABEL(label_statusm), "ERREUR: Échec de la modification");
    }

   
}


void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data) 
{

GtkWidget *fd_entry_del_id;
    GtkWidget *label_statusd;
    
    char id[50];
    int resultat;
    
    /* ========== GET WIDGETS ========== */
    fd_entry_del_id = lookup_widget(GTK_WIDGET(button), "fd_entry_del_id");
    label_statusd = lookup_widget(GTK_WIDGET(button), "label_statusd");
    
    /* ========== VALIDATE WIDGETS ========== */
    if (!fd_entry_del_id || !label_statusd)
    {
        return;
    }
    
    /* ========== GET ID VALUE ========== */
    strcpy(id, gtk_entry_get_text(GTK_ENTRY(fd_entry_del_id)));
    
    /* ========== VALIDATE REQUIRED FIELD ========== */
    if (strlen(id) == 0)
    {
        gtk_label_set_text(GTK_LABEL(label_statusd), "ERREUR: ID requis pour suppression");
        return;
    }
    
    /* ========== CALL DELETE FUNCTION ========== */
    resultat = supprimer_evenement("evenements.txt", id);
    
    /* ========== HANDLE RESULT ========== */
    if (resultat == 1)
    {
        gtk_label_set_text(GTK_LABEL(label_statusd), "Événement supprimé avec succès");
        gtk_entry_set_text(GTK_ENTRY(fd_entry_del_id), "");
    }
    else
    {
        gtk_label_set_text(GTK_LABEL(label_statusd), "ERREUR: Événement non trouvé");
    }

}
void on_fd_win_espace_admin_show(GtkWidget *widget, gpointer user_data) {
    g_print("\n=== DEBUG: on_fd_win_espace_admin_show called ===\n");
    g_print("Widget: %p (type: %s)\n", widget, G_OBJECT_TYPE_NAME(widget));
    
    // Get the TreeView widget
    GtkWidget *fd_treeview_evenements = lookup_widget(widget, "fd_treeview_evenements");
    
    if (fd_treeview_evenements != NULL) {
        g_print("SUCCESS: Found fd_treeview_evenements at %p\n", fd_treeview_evenements);
        g_print("TreeView type: %s\n", G_OBJECT_TYPE_NAME(fd_treeview_evenements));
        
        // Check if file exists
        FILE *test = fopen("evenements.txt", "r");
        if (test) {
            g_print("File evenements.txt exists\n");
            fclose(test);
        } else {
            g_print("WARNING: File evenements.txt does not exist or cannot be read\n");
        }
        
        // Call display function
        afficher_evenements(fd_treeview_evenements, "evenements.txt");
        
        // Check how many rows are in the TreeView
        GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(fd_treeview_evenements));
        if (model) {
            int rows = gtk_tree_model_iter_n_children(model, NULL);
            g_print("TreeView now has %d rows\n", rows);
        }
    } else {
        g_print("ERROR: fd_treeview_evenements not found!\n");
        
        // Try alternative names
        GtkWidget *treeview1 = lookup_widget(widget, "treeview1");
        if (treeview1) g_print("Found treeview1 instead\n");
        
        GtkWidget *treeview = lookup_widget(widget, "treeview");
        if (treeview) g_print("Found treeview instead\n");
        
        // List all child widgets to see what's available
        g_print("Listing child widgets...\n");
        if (GTK_IS_CONTAINER(widget)) {
            GList *children = gtk_container_get_children(GTK_CONTAINER(widget));
            GList *iter = children;
            while (iter) {
                GtkWidget *child = GTK_WIDGET(iter->data);
                const gchar *name = gtk_widget_get_name(child);
                g_print("  - Child: %p, Type: %s, Name: %s\n", 
                       child, G_OBJECT_TYPE_NAME(child), name ? name : "(no name)");
                iter = iter->next;
            }
            g_list_free(children);
        }
    }
    g_print("=== DEBUG END ===\n\n");

g_print("Current directory: ");
system("pwd");

}


