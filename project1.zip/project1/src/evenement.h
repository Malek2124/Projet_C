#ifndef EVENEMENT_H_INCLUDED
#define EVENEMENT_H_INCLUDED

#include <stdio.h>
#include <gtk/gtk.h> // Nécessaire pour le prototype de la fonction d'affichage

// Définition de la structure pour un événement
typedef struct {
    char id[10];            
    char nom[50];
    char date[15];          // Format JJ/MM/AAAA
    char heure[10];         // Format HH:MM
    char lieu[50];
    int participants_max;
    float frais;
    char centre[20];        
    int equipements;        // 0 = Non, 1 = Oui
} Evenement;

// Définition de la structure pour l'inscription/affectation
typedef struct {
    char member_id[10]; 
    char event_id[10];  
} Inscription;


// Prototypes des fonctions de gestion de fichiers (CRUD) pour Evenement
int ajouter_evenement(char *filename, Evenement e);
Evenement chercher_evenement(char *filename, char *id);
int modifier_evenement(char *filename, char *id, Evenement nouv);
int supprimer_evenement(char *filename, char *id);

// Prototype de la fonction pour l'affectation (Coach ou Membre à un événement)
int affecter_coach_event(char *filename, Inscription i);


// Prototypes pour l'affichage GTK :
void afficher_evenements(GtkWidget *liste, char *filename);


void afficher_evenements_filtre(GtkWidget *liste, char *filename, const char *search_nom);
#endif // EVENEMENT_H_INCLUDED
