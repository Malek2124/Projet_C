/*#include "evenement.h"
#include <stdlib.h>
#include <string.h>

// Chemin du fichier de données des événements
#define EVENT_FILE "evenements.txt"

// --- Fonctions de Gestion de Base (CRUD) ---

int ajouter_evenement(char *filename, Evenement e) {
    FILE *f = fopen(filename, "a");
    if (f != NULL) {
        // ID Nom Date Heure Lieu MaxFrais Frais Centre Equipements
        fprintf(f, "%s %s %s %s %s %d %.2f %s %d\n",
                e.id, e.nom, e.date, e.heure, e.lieu, 
                e.participants_max, e.frais, e.centre, e.equipements);
        fclose(f);
        return 1;
    } else {
        return 0; 
    }
}

Evenement chercher_evenement(char *filename, char *id) {
    Evenement e;
    int tr = 0; 
    FILE *f = fopen(filename, "r");

    strcpy(e.id, "-1"); 

    if (f != NULL) {
        while (tr == 0 && fscanf(f, "%s %s %s %s %s %d %f %s %d\n",
                                e.id, e.nom, e.date, e.heure, e.lieu, 
                                &e.participants_max, &e.frais, e.centre, &e.equipements) != EOF) {
            
            if (strcmp(e.id, id) == 0) {
                tr = 1; 
            }
        }
        fclose(f);
    }
    
    if (tr == 0) {
        strcpy(e.id, "-1");
    }
    return e;
}

int modifier_evenement(char *filename, char *id, Evenement nouv) {
    int tr = 0;
    Evenement e;
    FILE *f = fopen(filename, "r");
    FILE *f2 = fopen("temp_evenements.txt", "w");

    if (f != NULL && f2 != NULL) {
        while (fscanf(f, "%s %s %s %s %s %d %f %s %d\n",
                      e.id, e.nom, e.date, e.heure, e.lieu, 
                      &e.participants_max, &e.frais, e.centre, &e.equipements) != EOF) {

            if (strcmp(e.id, id) == 0) {
                fprintf(f2, "%s %s %s %s %s %d %.2f %s %d\n",
                        nouv.id, nouv.nom, nouv.date, nouv.heure, nouv.lieu, 
                        nouv.participants_max, nouv.frais, nouv.centre, nouv.equipements);
                tr = 1;
            } else {
                fprintf(f2, "%s %s %s %s %s %d %.2f %s %d\n",
                        e.id, e.nom, e.date, e.heure, e.lieu, 
                        e.participants_max, e.frais, e.centre, e.equipements);
            }
        }
    }
    
    fclose(f);
    fclose(f2);
    
    if (tr == 1) {
        remove(filename); 
        rename("temp_evenements.txt", filename); 
    } else {
        remove("temp_evenements.txt");
    }
    return tr;
}

int supprimer_evenement(char *filename, char *id) {
    int tr = 0;
    Evenement e;
    FILE *f = fopen(filename, "r");
    FILE *f2 = fopen("temp_evenements.txt", "w");

    if (f != NULL && f2 != NULL) {
        while (fscanf(f, "%s %s %s %s %s %d %f %s %d\n",
                      e.id, e.nom, e.date, e.heure, e.lieu, 
                      &e.participants_max, &e.frais, e.centre, &e.equipements) != EOF) {
            
            if (strcmp(e.id, id) == 0) {
                tr = 1; // On a trouvé, on ne copie pas
            } else {
                // On copie toutes les autres lignes
                fprintf(f2, "%s %s %s %s %s %d %.2f %s %d\n",
                        e.id, e.nom, e.date, e.heure, e.lieu, 
                        e.participants_max, e.frais, e.centre, e.equipements);
            }
        }
    }
    
    fclose(f);
    fclose(f2);
    
    if (tr == 1) {
        remove(filename);
        rename("temp_evenements.txt", filename);
    } else {
        remove("temp_evenements.txt");
    }
    return tr;
}

int affecter_coach_event(char *filename, Inscription i) {
    FILE *f = fopen(filename, "a");
    if (f != NULL) {
        // Format: ID_Membre/Coach ID_Evenement
        fprintf(f, "%s %s\n", i.member_id, i.event_id);
        fclose(f);
        return 1;
    } else {
        return 0;
    }
}


// --- Fonction GTK pour l'affichage dans la TreeView ---

enum {
    COL_ID,
    COL_NOM,
    COL_DATE,
    COL_HEURE,
    COL_LIEU,
    COL_MAX,
    COL_FRAIS,
    COL_CENTRE,
    COL_EQUIP,
    NUM_COLS
};

void afficher_evenements(GtkWidget *liste, char *filename) {
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkListStore *store;
    GtkTreeIter iter;

    Evenement e;
    FILE *f;

    // 1. Initialisation/Nettoyage de la liste
    store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(liste)));
    if (store == NULL) {
        store = gtk_list_store_new(NUM_COLS, 
                                   G_TYPE_STRING,   // COL_ID
                                   G_TYPE_STRING,   // COL_NOM
                                   G_TYPE_STRING,   // COL_DATE
                                   G_TYPE_STRING,   // COL_HEURE
                                   G_TYPE_STRING,   // COL_LIEU
                                   G_TYPE_INT,      // COL_MAX
                                   G_TYPE_FLOAT,    // COL_FRAIS
                                   G_TYPE_STRING,   // COL_CENTRE
                                   G_TYPE_INT       // COL_EQUIP 
                                   );
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
    }
    gtk_list_store_clear(store);


   // 2. Création des colonnes si elles n'existent pas
GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (model == NULL || gtk_tree_model_get_n_columns(model) == 0) {
    // If there's no model or no columns, create them
    
    #define ADD_COLUMN(title, col_id) \
        renderer = gtk_cell_renderer_text_new(); \
        column = gtk_tree_view_column_new_with_attributes(title, renderer, "text", col_id, NULL); \
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    
    ADD_COLUMN("ID", COL_ID);
    ADD_COLUMN("Nom", COL_NOM);
    ADD_COLUMN("Date", COL_DATE);
    ADD_COLUMN("Heure", COL_HEURE);
    ADD_COLUMN("Lieu", COL_LIEU);
    ADD_COLUMN("Max Part.", COL_MAX);
    ADD_COLUMN("Frais (€)", COL_FRAIS);
    ADD_COLUMN("Centre", COL_CENTRE);
    ADD_COLUMN("Equip. (1/0)", COL_EQUIP);

}







    // 3. Lecture et Remplissage
    f = fopen(filename, "r");
    if (f != NULL) {
        while (fscanf(f, "%s %s %s %s %s %d %f %s %d\n",
                      e.id, e.nom, e.date, e.heure, e.lieu, 
                      &e.participants_max, &e.frais, e.centre, &e.equipements) != EOF) {
            
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                               COL_ID, e.id,
                               COL_NOM, e.nom,
                               COL_DATE, e.date,
                               COL_HEURE, e.heure,
                               COL_LIEU, e.lieu,
                               COL_MAX, e.participants_max,
                               COL_FRAIS, e.frais,
                               COL_CENTRE, e.centre,
                               COL_EQUIP, e.equipements,
                               -1);
        }
        fclose(f);
    }
} 
/* Function t#include "evenement.h"
#include <stdlib.h>
#include <string.h>

// Chemin du fichier de données des événements
#define EVENT_FILE "evenements.txt"

// --- Fonctions de Gestion de Base (CRUD) ---

int ajouter_evenement(char *filename, Evenement e) {
    FILE *f = fopen(filename, "a");
    if (f != NULL) {
        // ID Nom Date Heure Lieu MaxFrais Frais Centre Equipements
        fprintf(f, "%s %s %s %s %s %d %.2f %s %d\n",
                e.id, e.nom, e.date, e.heure, e.lieu, 
                e.participants_max, e.frais, e.centre, e.equipements);
        fclose(f);
        return 1;
    } else {
        return 0; 
    }
}

Evenement chercher_evenement(char *filename, char *id) {
    Evenement e;
    int tr = 0; 
    FILE *f = fopen(filename, "r");

    strcpy(e.id, "-1"); 

    if (f != NULL) {
        while (tr == 0 && fscanf(f, "%s %s %s %s %s %d %f %s %d\n",
                                e.id, e.nom, e.date, e.heure, e.lieu, 
                                &e.participants_max, &e.frais, e.centre, &e.equipements) != EOF) {
            
            if (strcmp(e.id, id) == 0) {
                tr = 1; 
            }
        }
        fclose(f);
    }
    
    if (tr == 0) {
        strcpy(e.id, "-1");
    }
    return e;
}

int modifier_evenement(char *filename, char *id, Evenement nouv) {
    int tr = 0;
    Evenement e;
    FILE *f = fopen(filename, "r");
    FILE *f2 = fopen("temp_evenements.txt", "w");

    if (f != NULL && f2 != NULL) {
        while (fscanf(f, "%s %s %s %s %s %d %f %s %d\n",
                      e.id, e.nom, e.date, e.heure, e.lieu, 
                      &e.participants_max, &e.frais, e.centre, &e.equipements) != EOF) {

            if (strcmp(e.id, id) == 0) {
                fprintf(f2, "%s %s %s %s %s %d %.2f %s %d\n",
                        nouv.id, nouv.nom, nouv.date, nouv.heure, nouv.lieu, 
                        nouv.participants_max, nouv.frais, nouv.centre, nouv.equipements);
                tr = 1;
            } else {
                fprintf(f2, "%s %s %s %s %s %d %.2f %s %d\n",
                        e.id, e.nom, e.date, e.heure, e.lieu, 
                        e.participants_max, e.frais, e.centre, e.equipements);
            }
        }
    }
    
    fclose(f);
    fclose(f2);
    
    if (tr == 1) {
        remove(filename); 
        rename("temp_evenements.txt", filename); 
    } else {
        remove("temp_evenements.txt");
    }
    return tr;
}

int supprimer_evenement(char *filename, char *id) {
    int tr = 0;
    Evenement e;
    FILE *f = fopen(filename, "r");
    FILE *f2 = fopen("temp_evenements.txt", "w");

    if (f != NULL && f2 != NULL) {
        while (fscanf(f, "%s %s %s %s %s %d %f %s %d\n",
                      e.id, e.nom, e.date, e.heure, e.lieu, 
                      &e.participants_max, &e.frais, e.centre, &e.equipements) != EOF) {
            
            if (strcmp(e.id, id) == 0) {
                tr = 1; // On a trouvé, on ne copie pas
            } else {
                // On copie toutes les autres lignes
                fprintf(f2, "%s %s %s %s %s %d %.2f %s %d\n",
                        e.id, e.nom, e.date, e.heure, e.lieu, 
                        e.participants_max, e.frais, e.centre, e.equipements);
            }
        }
    }
    
    fclose(f);
    fclose(f2);
    
    if (tr == 1) {
        remove(filename);
        rename("temp_evenements.txt", filename);
    } else {
        remove("temp_evenements.txt");
    }
    return tr;
}

int affecter_coach_event(char *filename, Inscription i) {
    FILE *f = fopen(filename, "a");
    if (f != NULL) {
        // Format: ID_Membre/Coach ID_Evenement
        fprintf(f, "%s %s\n", i.member_id, i.event_id);
        fclose(f);
        return 1;
    } else {
        return 0;
    }
}


// --- Fonction GTK pour l'affichage dans la TreeView ---

enum {
    COL_ID,
    COL_NOM,
    COL_DATE,
    COL_HEURE,
    COL_LIEU,
    COL_MAX,
    COL_FRAIS,
    COL_CENTRE,
    COL_EQUIP,
    NUM_COLS
};

void afficher_evenements(GtkWidget *liste, char *filename) {
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkListStore *store;
    GtkTreeIter iter;

    Evenement e;
    FILE *f;

    // 1. Initialisation/Nettoyage de la liste
    store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(liste)));
    if (store == NULL) {
        store = gtk_list_store_new(NUM_COLS, 
                                   G_TYPE_STRING,   // COL_ID
                                   G_TYPE_STRING,   // COL_NOM
                                   G_TYPE_STRING,   // COL_DATE
                                   G_TYPE_STRING,   // COL_HEURE
                                   G_TYPE_STRING,   // COL_LIEU
                                   G_TYPE_INT,      // COL_MAX
                                   G_TYPE_FLOAT,    // COL_FRAIS
                                   G_TYPE_STRING,   // COL_CENTRE
                                   G_TYPE_INT       // COL_EQUIP 
                                   );
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
    }
    gtk_list_store_clear(store);

    // 2. Création des colonnes si elles n'existent pas
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
    if (model != NULL && gtk_tree_model_get_n_columns(model) == 0) {
        
        #define ADD_COLUMN(title, col_id) \
            renderer = gtk_cell_renderer_text_new(); \
            column = gtk_tree_view_column_new_with_attributes(title, renderer, "text", col_id, NULL); \
            gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        ADD_COLUMN("ID", COL_ID);
        ADD_COLUMN("Nom", COL_NOM);
        ADD_COLUMN("Date", COL_DATE);
        ADD_COLUMN("Heure", COL_HEURE);
        ADD_COLUMN("Lieu", COL_LIEU);
        ADD_COLUMN("Max Part.", COL_MAX);
        ADD_COLUMN("Frais (€)", COL_FRAIS);
        ADD_COLUMN("Centre", COL_CENTRE);
        ADD_COLUMN("Equip. (1/0)", COL_EQUIP);
    }

    // 3. Lecture et Remplissage
    f = fopen(filename, "r");
    if (f != NULL) {
        while (fscanf(f, "%s %s %s %s %s %d %f %s %d\n",
                      e.id, e.nom, e.date, e.heure, e.lieu, 
                      &e.participants_max, &e.frais, e.centre, &e.equipements) != EOF) {
            
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                               COL_ID, e.id,
                               COL_NOM, e.nom,
                               COL_DATE, e.date,
                               COL_HEURE, e.heure,
                               COL_LIEU, e.lieu,
                               COL_MAX, e.participants_max,
                               COL_FRAIS, e.frais,
                               COL_CENTRE, e.centre,
                               COL_EQUIP, e.equipements,
                               -1);
        }
        fclose(f);
    }
} 

/* Function to display filtered events in TreeView
void afficher_evenements_filtre(GtkWidget *liste, char *filename, const char *search_nom)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkListStore *store;
    GtkTreeIter iter;

    Evenement e;
    FILE *f;

    // 1. Initialisation/Nettoyage de la liste
    store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(liste)));
    if (store == NULL) {
        store = gtk_list_store_new(NUM_COLS, 
                                   G_TYPE_STRING,   // COL_ID
                                   G_TYPE_STRING,   // COL_NOM
                                   G_TYPE_STRING,   // COL_DATE
                                   G_TYPE_STRING,   // COL_HEURE
                                   G_TYPE_STRING,   // COL_LIEU
                                   G_TYPE_INT,      // COL_MAX
                                   G_TYPE_FLOAT,    // COL_FRAIS
                                   G_TYPE_STRING,   // COL_CENTRE
                                   G_TYPE_INT       // COL_EQUIP 
                                   );
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
    }
    gtk_list_store_clear(store);

    // 2. Création des colonnes si elles n'existent pas
    GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
    if (model != NULL && gtk_tree_model_get_n_columns(model) == 0) {
        
        #define ADD_COLUMN(title, col_id) \
            renderer = gtk_cell_renderer_text_new(); \
            column = gtk_tree_view_column_new_with_attributes(title, renderer, "text", col_id, NULL); \
            gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

        ADD_COLUMN("ID", COL_ID);
        ADD_COLUMN("Nom", COL_NOM);
        ADD_COLUMN("Date", COL_DATE);
        ADD_COLUMN("Heure", COL_HEURE);
        ADD_COLUMN("Lieu", COL_LIEU);
        ADD_COLUMN("Max Part.", COL_MAX);
        ADD_COLUMN("Frais (€)", COL_FRAIS);
        ADD_COLUMN("Centre", COL_CENTRE);
        ADD_COLUMN("Equip. (1/0)", COL_EQUIP);
    }

    // 3. Lecture et Remplissage avec FILTRE
    f = fopen(filename, "r");
    if (f != NULL) {
        while (fscanf(f, "%s %s %s %s %s %d %f %s %d\n",
                      e.id, e.nom, e.date, e.heure, e.lieu, 
                      &e.participants_max, &e.frais, e.centre, &e.equipements) != EOF) {
            
            /* FILTER: Only add if nom contains search_nom (case insensitive)
            if (search_nom == NULL || strlen(search_nom) == 0 || 
                strcasestr(e.nom, search_nom) != NULL) {
                
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store, &iter,
                                   COL_ID, e.id,
                                   COL_NOM, e.nom,
                                   COL_DATE, e.date,
                                   COL_HEURE, e.heure,
                                   COL_LIEU, e.lieu,
                                   COL_MAX, e.participants_max,
                                   COL_FRAIS, e.frais,
                                   COL_CENTRE, e.centre,
                                   COL_EQUIP, e.equipements,
                                   -1);
            }
        }
        fclose(f);
    }
}o display filtered events in TreeView
void afficher_evenements_filtre(GtkWidget *liste, char *filename, const char *search_nom)
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkListStore *store;
    GtkTreeIter iter;

    Evenement e;
    FILE *f;

    // 1. Initialisation/Nettoyage de la liste
    store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(liste)));
    if (store == NULL) {
        store = gtk_list_store_new(NUM_COLS, 
                                   G_TYPE_STRING,   // COL_ID
                                   G_TYPE_STRING,   // COL_NOM
                                   G_TYPE_STRING,   // COL_DATE
                                   G_TYPE_STRING,   // COL_HEURE
                                   G_TYPE_STRING,   // COL_LIEU
                                   G_TYPE_INT,      // COL_MAX
                                   G_TYPE_FLOAT,    // COL_FRAIS
                                   G_TYPE_STRING,   // COL_CENTRE
                                   G_TYPE_INT       // COL_EQUIP 
                                   );
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
    }
    gtk_list_store_clear(store);

 2. Création des colonnes si elles n'existent pas
GtkTreeModel *model = gtk_tree_view_get_model(GTK_TREE_VIEW(liste));
if (model == NULL || gtk_tree_model_get_n_columns(model) == 0) {
    
    #define ADD_COLUMN(title, col_id) \
        renderer = gtk_cell_renderer_text_new(); \
        column = gtk_tree_view_column_new_with_attributes(title, renderer, "text", col_id, NULL); \
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);

    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    
    ADD_COLUMN("ID", COL_ID);
    ADD_COLUMN("Nom", COL_NOM);
    ADD_COLUMN("Date", COL_DATE);
    ADD_COLUMN("Heure", COL_HEURE);
    ADD_COLUMN("Lieu", COL_LIEU);
    ADD_COLUMN("Max Part.", COL_MAX);
    ADD_COLUMN("Frais (€)", COL_FRAIS);
    ADD_COLUMN("Centre", COL_CENTRE);
    ADD_COLUMN("Equip. (1/0)", COL_EQUIP);
    
    #undef ADD_COLUMN
}






    // 3. Lecture et Remplissage avec FILTRE
    f = fopen(filename, "r");
    if (f != NULL) {
        while (fscanf(f, "%s %s %s %s %s %d %f %s %d\n",
                      e.id, e.nom, e.date, e.heure, e.lieu, 
                      &e.participants_max, &e.frais, e.centre, &e.equipements) != EOF) {
            
            /* FILTER: Only add if nom contains search_nom (case insensitive) 
            if (search_nom == NULL || strlen(search_nom) == 0 || 
                strcasestr(e.nom, search_nom) != NULL) {
                
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store, &iter,
                                   COL_ID, e.id,
                                   COL_NOM, e.nom,
                                   COL_DATE, e.date,
                                   COL_HEURE, e.heure,
                                   COL_LIEU, e.lieu,
                                   COL_MAX, e.participants_max,
                                   COL_FRAIS, e.frais,
                                   COL_CENTRE, e.centre,
                                   COL_EQUIP, e.equipements,
                                   -1);
            }
        }
        fclose(f);
    }
}*/



#include "evenement.h"
#include <stdlib.h>
#include <string.h>
#include <ctype.h>  // Added for tolower()

// Chemin du fichier de données des événements
#define EVENT_FILE "evenements.txt"

// --- Fonctions de Gestion de Base (CRUD) ---

int ajouter_evenement(char *filename, Evenement e) {
    FILE *f = fopen(filename, "a");
    if (f != NULL) {
        // ID Nom Date Heure Lieu MaxFrais Frais Centre Equipements
        fprintf(f, "%s %s %s %s %s %d %.2f %s %d\n",
                e.id, e.nom, e.date, e.heure, e.lieu, 
                e.participants_max, e.frais, e.centre, e.equipements);
        fclose(f);
        return 1;
    } else {
        return 0; 
    }
}

Evenement chercher_evenement(char *filename, char *id) {
    Evenement e;
    int tr = 0; 
    FILE *f = fopen(filename, "r");

    strcpy(e.id, "-1"); 

    if (f != NULL) {
        while (tr == 0 && fscanf(f, "%s %s %s %s %s %d %f %s %d\n",
                                e.id, e.nom, e.date, e.heure, e.lieu, 
                                &e.participants_max, &e.frais, e.centre, &e.equipements) != EOF) {
            
            if (strcmp(e.id, id) == 0) {
                tr = 1; 
            }
        }
        fclose(f);
    }
    
    if (tr == 0) {
        strcpy(e.id, "-1");
    }
    return e;
}

int modifier_evenement(char *filename, char *id, Evenement nouv) {
    int tr = 0;
    Evenement e;
    FILE *f = fopen(filename, "r");
    FILE *f2 = fopen("temp_evenements.txt", "w");

    if (f != NULL && f2 != NULL) {
        while (fscanf(f, "%s %s %s %s %s %d %f %s %d\n",
                      e.id, e.nom, e.date, e.heure, e.lieu, 
                      &e.participants_max, &e.frais, e.centre, &e.equipements) != EOF) {

            if (strcmp(e.id, id) == 0) {
                fprintf(f2, "%s %s %s %s %s %d %.2f %s %d\n",
                        nouv.id, nouv.nom, nouv.date, nouv.heure, nouv.lieu, 
                        nouv.participants_max, nouv.frais, nouv.centre, nouv.equipements);
                tr = 1;
            } else {
                fprintf(f2, "%s %s %s %s %s %d %.2f %s %d\n",
                        e.id, e.nom, e.date, e.heure, e.lieu, 
                        e.participants_max, e.frais, e.centre, e.equipements);
            }
        }
    }
    
    fclose(f);
    fclose(f2);
    
    if (tr == 1) {
        remove(filename); 
        rename("temp_evenements.txt", filename); 
    } else {
        remove("temp_evenements.txt");
    }
    return tr;
}

int supprimer_evenement(char *filename, char *id) {
    int tr = 0;
    Evenement e;
    FILE *f = fopen(filename, "r");
    FILE *f2 = fopen("temp_evenements.txt", "w");

    if (f != NULL && f2 != NULL) {
        while (fscanf(f, "%s %s %s %s %s %d %f %s %d\n",
                      e.id, e.nom, e.date, e.heure, e.lieu, 
                      &e.participants_max, &e.frais, e.centre, &e.equipements) != EOF) {
            
            if (strcmp(e.id, id) == 0) {
                tr = 1; // On a trouvé, on ne copie pas
            } else {
                // On copie toutes les autres lignes
                fprintf(f2, "%s %s %s %s %s %d %.2f %s %d\n",
                        e.id, e.nom, e.date, e.heure, e.lieu, 
                        e.participants_max, e.frais, e.centre, e.equipements);
            }
        }
    }
    
    fclose(f);
    fclose(f2);
    
    if (tr == 1) {
        remove(filename);
        rename("temp_evenements.txt", filename);
    } else {
        remove("temp_evenements.txt");
    }
    return tr;
}

int affecter_coach_event(char *filename, Inscription i) {
    FILE *f = fopen(filename, "a");
    if (f != NULL) {
        // Format: ID_Membre/Coach ID_Evenement
        fprintf(f, "%s %s\n", i.member_id, i.event_id);
        fclose(f);
        return 1;
    } else {
        return 0;
    }
}

// Helper function for case-insensitive string contains
static int contains_case_insensitive(const char *str, const char *substr) {
    if (str == NULL || substr == NULL) return 1;
    
    // Create lowercase copies
    char str_lower[256];
    char substr_lower[256];
    int i;
    
    // Copy and convert to lowercase
    for (i = 0; str[i] && i < 255; i++) {
        str_lower[i] = tolower(str[i]);
    }
    str_lower[i] = '\0';
    
    for (i = 0; substr[i] && i < 255; i++) {
        substr_lower[i] = tolower(substr[i]);
    }
    substr_lower[i] = '\0';
    
    // Check if substr_lower is in str_lower
    return (strstr(str_lower, substr_lower) != NULL);
}

// --- Fonction GTK pour l'affichage dans la TreeView ---

enum {
    COL_ID,
    COL_NOM,
    COL_DATE,
    COL_HEURE,
    COL_LIEU,
    COL_MAX,
    COL_FRAIS,
    COL_CENTRE,
    COL_EQUIP,
    NUM_COLS
};




void afficher_evenements(GtkWidget *liste, char *filename) {
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkListStore *store;
    GtkTreeIter iter;
    Evenement e;
    FILE *f;

    // 1. Get existing model (might be NULL)
    store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(liste)));
    
    // 2. If NO model exists, create columns and model
    if (store == NULL) {
        g_print("Creating columns and model...\n");
        
        // CREATE COLUMNS FIRST
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("ID", renderer, "text", COL_ID, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", COL_NOM, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text", COL_DATE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Heure", renderer, "text", COL_HEURE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Lieu", renderer, "text", COL_LIEU, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Max Part.", renderer, "text", COL_MAX, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Frais (€)", renderer, "text", COL_FRAIS, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Centre", renderer, "text", COL_CENTRE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Equip.", renderer, "text", COL_EQUIP, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        // THEN CREATE MODEL
        store = gtk_list_store_new(NUM_COLS, 
            G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
            G_TYPE_STRING, G_TYPE_INT, G_TYPE_FLOAT, G_TYPE_STRING, G_TYPE_INT);
        
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
        g_object_unref(store);  // IMPORTANT: TreeView has its own reference
    }
    
    // 3. Clear existing data
    gtk_list_store_clear(store);
    
    // 4. Load data from file
    f = fopen(filename, "r");
    if (f != NULL) {
        int count = 0;
        while (fscanf(f, "%s %s %s %s %s %d %f %s %d\n",
                      e.id, e.nom, e.date, e.heure, e.lieu, 
                      &e.participants_max, &e.frais, e.centre, &e.equipements) != EOF) {
            
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter,
                COL_ID, e.id, COL_NOM, e.nom, COL_DATE, e.date,
                COL_HEURE, e.heure, COL_LIEU, e.lieu, COL_MAX, e.participants_max,
                COL_FRAIS, e.frais, COL_CENTRE, e.centre, COL_EQUIP, e.equipements, -1);
            count++;
        }
        fclose(f);
        g_print("Loaded %d events into TreeView\n", count);
    } else {
        g_print("ERROR: Could not open file %s\n", filename);
    }
}


void afficher_evenements_filtre(GtkWidget *liste, char *filename, const char *search_nom) {
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkListStore *store;
    GtkTreeIter iter;
    Evenement e;
    FILE *f;

    // 1. Get existing model (might be NULL)
    store = GTK_LIST_STORE(gtk_tree_view_get_model(GTK_TREE_VIEW(liste)));
    
    // 2. If NO model exists, create columns and model
    if (store == NULL) {
        g_print("Creating columns and model for filtered view...\n");
        
        // CREATE COLUMNS FIRST
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("ID", renderer, "text", COL_ID, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Nom", renderer, "text", COL_NOM, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Date", renderer, "text", COL_DATE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Heure", renderer, "text", COL_HEURE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Lieu", renderer, "text", COL_LIEU, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Max Part.", renderer, "text", COL_MAX, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Frais (€)", renderer, "text", COL_FRAIS, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Centre", renderer, "text", COL_CENTRE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes("Equip.", renderer, "text", COL_EQUIP, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
        
        // THEN CREATE MODEL
        store = gtk_list_store_new(NUM_COLS, 
            G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,
            G_TYPE_STRING, G_TYPE_INT, G_TYPE_FLOAT, G_TYPE_STRING, G_TYPE_INT);
        
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
        g_object_unref(store);  // IMPORTANT: TreeView has its own reference
    }
    
    // 3. Clear existing data
    gtk_list_store_clear(store);
    
    // 4. Load filtered data from file
    f = fopen(filename, "r");
    if (f != NULL) {
        int count = 0;
        while (fscanf(f, "%s %s %s %s %s %d %f %s %d\n",
                      e.id, e.nom, e.date, e.heure, e.lieu, 
                      &e.participants_max, &e.frais, e.centre, &e.equipements) != EOF) {
            
            /* FILTER: Only add if nom contains search_nom (case insensitive) */
            if (search_nom == NULL || strlen(search_nom) == 0 || 
                contains_case_insensitive(e.nom, search_nom)) {
                
                gtk_list_store_append(store, &iter);
                gtk_list_store_set(store, &iter,
                    COL_ID, e.id, COL_NOM, e.nom, COL_DATE, e.date,
                    COL_HEURE, e.heure, COL_LIEU, e.lieu, COL_MAX, e.participants_max,
                    COL_FRAIS, e.frais, COL_CENTRE, e.centre, COL_EQUIP, e.equipements, -1);
                count++;
            }
        }
        fclose(f);
        g_print("Filtered view: Loaded %d events\n", count);
    } else {
        g_print("ERROR: Could not open file %s for filtered view\n", filename);
    }
}







