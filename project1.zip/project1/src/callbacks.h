#include <gtk/gtk.h>


gboolean
fd_on_win_admin_delete_event           (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);

gboolean
fd_on_win_register_delete_event        (GtkWidget       *widget,
                                        GdkEvent        *event,
                                        gpointer         user_data);
void
on_fd_btn_ajouter1_confirm_clicked      (GtkButton       *button,
                                        gpointer         user_data);


/*void
on_fd_btn_mod_search_clicked           (GtkButton       *button,
                                        gpointer         user_data);*/

void
on_fd_btn_modifier_confirm_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_fd_btn_rechercher_confirm_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_fd_btn_register_event_clicked       (GtkButton       *button,
                                        gpointer         user_data);


void
on_fd_win_espace_admin_show            (GtkWidget        *widget,
                                        gpointer         user_data);

void
on_fd_win_register_event_show          (GtkWidget       *widget,
                                        gpointer         user_data);
